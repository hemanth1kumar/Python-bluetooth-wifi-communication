import os
from bluetooth import *
# Create the client socket
sock=BluetoothSocket( RFCOMM )
host="94:E9:79:5A:E3:F4"
port = 6
sock.connect((host,port))
buff=35675

while True:
	data_type = raw_input("1.text , 2.multimedia , 3.file , 4.exit: ")
	sock.sendall(data_type)
	if data_type == "1":
		data = raw_input("Enter message to send or type 'exit': ")
		sock.sendall(data)
		if data == "exit":
			break
	
	elif data_type == "2":
		specify = raw_input("Image or Video: ")
		sock.sendall(specify)
		if specify == "Image":
			filename = raw_input("image name with extension as .png or .jpg : ")
			sock.sendall(filename)
			f = open(filename,'rb')
			l = f.read()
			while (l):
				sock.sendall(l)
				print('Sent ',repr(l))
				l = f.read(buff)
			f.close()
			sock.sendall("123stop")
			print ("Image sent to server successfully")

		elif specify == "Video":
			filename = raw_input("image name with extension as .png or .jpg : ")			
			sock.sendall(filename)
			f = open(filename,'rb')
			l = f.read()
			while (l):
				sock.sendall(l)
				print('Sent ',repr(l))
				l = f.read(buff)
			f.close()
			sock.sendall("123stop")
			print ("Video sent to server successfully")			
			                        
	elif data_type == "3":
		filename=raw_input("Enter filename as input with extensions as .mp4 or .mp3 or .html : ")
		sock.sendall(filename)
		f = open(filename,'rb')
		l = f.read()
		while (l):
			sock.sendall(l)
			print('Sent ',repr(l))
			l = f.read(buff)
		f.close()
		sock.sendall("123stop")	
	elif data_type == "4":
		break
sock.close()
os._exit(0)
