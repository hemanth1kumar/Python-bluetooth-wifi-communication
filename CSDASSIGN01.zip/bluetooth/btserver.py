from bluetooth import *

buff=35675
sock=BluetoothSocket( RFCOMM )

sock.bind(("", 5 ))
sock.listen(1)

conn, address = sock.accept()
print ("Waiting to Receive data......")


while True:
        data = conn.recv(buff)

        if data == "1":
                data = conn.recv(buff)
                print ("Recieved Text: " + str(data))

        elif data == "2":
                data = conn.recv(buff)
                if data == "Image":
                       
                	data = conn.recv(buff)
			with open(data, 'wb') as f:
    				print 'file opened'
    				while True:
        			
        				data = conn.recv(buff)
        				if data == "123stop":
						f.close()
            					break
        				f.write(data)
			f.close()
			print('Successfully Received the Image')
			
                elif data == "Video":
                	data = conn.recv(buff)
			with open(data, 'wb') as f:
    				print 'file opened'
    				while True:
        			
        				data = conn.recv(buff)
        				if data == "123stop":
						f.close()
            					break
        				f.write(data)
			f.close()
			print('Successfully Received the Video')
			     

        elif data == "3":
                filename = conn.recv(buff)
		with open(filename, 'wb') as f:
    			print 'file opened'
    			while True:
        			
        			data = conn.recv(buff)
        			if data == "123stop":
					f.close()
            				break
        			f.write(data)
		f.close()
		print('Successfully Received the file')
		
	elif data == "4":
		break


sock.close()
os._exit(0)
