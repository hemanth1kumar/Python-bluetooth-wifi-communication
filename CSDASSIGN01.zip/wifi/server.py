import os

from socket import *


host = ''
port =7705
buff = 32765
address = (host, port)
sock = socket(AF_INET, SOCK_STREAM)
sock.bind(address)

sock.listen(1)
conn, address = sock.accept()

print ("Waiting to Receive data......")

i, j, k = 0, 0, 0
while True:
        data = conn.recv(buff)

        if data == "1":
                data = conn.recv(buff)
                print ("Recieved Text: " + str(data))

        elif data == "2":
                data = conn.recv(buff)
                if data == "Image":
                       
                	data = conn.recv(buff)
			with open(data, 'wb') as f:
    				print 'file opened'
    				while True:
        			
        				data = conn.recv(buff)
        				if data == "123stop":
						f.close()
            					break
        				f.write(data)
			f.close()
			print('Successfully Received the Image')
			
                elif data == "Video":
                	data = conn.recv(buff)
			with open(data, 'wb') as f:
    				print 'file opened'
    				while True:
        			
        				data = conn.recv(buff)
        				if data == "123stop":
						f.close()
            					break
        				f.write(data)
			f.close()
			print('Successfully Received the Video')
			     

        elif data == "3":
                data = conn.recv(buff)
		with open(data, 'wb') as f:
    			print 'file opened'
    			while True:
        			
        			data = conn.recv(buff)
        			if data == "123stop":
					f.close()
            				break
        			f.write(data)
		f.close()
		print('Successfully Received the file')
		
	elif data == "4":
		break


sock.close()
os._exit(0)
