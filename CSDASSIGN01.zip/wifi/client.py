import os
import json

from socket import *

host = '192.168.43.159'
port = 7702
buff= 32765
address = (host, port)
sock = socket(AF_INET, SOCK_STREAM)
sock.connect(address)

while True:
        data_type = raw_input("1.Texting \n2.multimedia \n3.file \n4.exit: \n")

        sock.sendall(data_type)
        
        if data_type == "1":
                data = raw_input("Enter message or type 'exit': ")
                sock.sendall(data)
                if data == "exit":
                        break
	
        elif data_type == "2":
                specify = raw_input("Image or Video: ")
                sock.sendall(specify)

                if specify == "Image":
                        filename = raw_input("image name with extension as .png or .jpg : ")			
			sock.sendall(filename)
    			f = open(filename,'rb')
    			l = f.read()
    			while (l):
       				sock.sendall(l)
       				print('Sent ',repr(l))
       				l = f.read(buff)				#0000
    			f.close()
			sock.sendall("123stop")
			print "Image sent to server successfully"

		elif specify == "Video":
			filename = raw_input("image name with extension as .png or .jpg : ")			
			sock.sendall(filename)
    			f = open(filename,'rb')
    			l = f.read()
    			while (l):
       				sock.sendall(l)
       				print('Sent ',repr(l))
       				l = f.read(buff)
    			f.close()
			sock.sendall("123stop")
			print "Video sent to server successfully"			
			                        
			                        
        elif data_type == "3":
                filename=raw_input("Enter filename as input with extensions as .mp4 or .mp3 or .html : ")
		sock.sendall(filename)
    		f = open(filename,'rb')
    		l = f.read()
    		while (l):
       			sock.sendall(l)
       			print('Sent ',repr(l))
       			l = f.read(buff)
    		f.close()
		sock.sendall("stopp")	
	elif data_type == "4":
		break
	else:
		print('Invalid Input ...Please try again')
sock.close()
os._exit(0)
